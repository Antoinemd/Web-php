<?php
define("MYHOST","localhost");
define("MYUSER","root");
define("MYPASS","");
?>