<!-- code html -->
<?php
	include_once("myparam.inc.php");
	if($idcom = connexpdo("magasin","myparam")) {
		$requete = "SELECT * FROM article ORDER BY categorie";
		$resultat = $idcom->query($requete);
		echo "<table>";
		echo "<tr><th>Code article</th><th>Description</th>
		<th>Prix</th><th>Catégorie</th></tr>";
		$lignes = $resultat->fetchAll(PDO::FETCH_NUM);
		for($i=0; $i<count($lignes); $i++) {
			echo "<tr>";
			for ($j=0; $j < count($lignes[i]); $j++) { 
				echo "<td>" . utf8_encode($lignes[i][j]) .
				"</td>";
			}
			echo "</tr>";
		}
	echo "</table>";
	$resultat->closeCursor();
	$idcom = NULL;
	}
?>
<!-- code html -->