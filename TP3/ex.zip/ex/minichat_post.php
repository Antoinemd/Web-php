<?php
// Connexion à la base de données
try
{
    include_once("connexpdo.inc.php");
	$idcom = connexpdo("magasin","myparam");
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}

// Insertion du message à l'aide d'une requête préparée
$requete = $idcom->prepare('INSERT INTO minichat (pseudo, message) VALUES(?, ?)');
$requete->execute(array($_POST['pseudo'], $_POST['message']));

// Redirection du visiteur vers la page du minichat
header('Location: minichat.php');
?>