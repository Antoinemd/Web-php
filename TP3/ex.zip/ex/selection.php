<!-- code html -->
<?php
	try
	{	
		include_once("myparam.inc.php");
		$idcom = connexpdo("autre","myparam");
	}	
	catch(Exception $e)
	{
        die('Erreur : '.$e->getMessage());
	}
	
	$requete = $idcom->prepare('SELECT categorie, prix FROM article WHERE categorie = ?  AND prix <= ? ORDER BY prix');
	$requete->execute(array($_GET['categorie'], $_GET['prix_max']));

	echo '<ul>';
	while ($donnees = $requete->fetch())
	{
		echo '<li>' . $donnees['description'] . $donnees['categorie'] . ' (' . $donnees['prix'] . ' EUR)</li>';
	}
	echo '</ul>';

	$requete->closeCursor();
	$idcom = NULL;
?>
<!-- code html -->


